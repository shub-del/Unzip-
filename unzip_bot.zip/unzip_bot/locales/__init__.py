from .strings import get_string, STRINGS
__all__ = ["get_string", "STRINGS"]
